#include <stdio.h>
#include <gtk/gtk.h>
#include <malloc.h>
#include "library.h"

int main(int argc, char *argv[]) {
    DialogInit();
    const char* folders = DialogOpenFolderPanel("Unity Open Folders", "/", true);
    printf("Folders selected: %s\n", folders);
    //const char* files = DialogOpenFilePanel("Unity Open File", "", "", true);
    //printf("Open files selected: %s\n", files);
    const char* filesFilters = DialogOpenFilePanel("Unity Open Files With Filters", "", "Text Files;txt,csv|Image Files;png,jpg,jpeg|Sound Files;mp3,wav|All Files;*", true);
    printf("Open files selected (with filter): %s\n", filesFilters);
	const char* saveFile = DialogSaveFilePanel("Unity Save File With Filters", "", "MySaveFile", "Text Files;txt,csv|Image Files;png,jpg,jpeg|Sound Files;mp3,wav|All Files;*");
    printf("Save file selected: %s\n", saveFile);
    return 0;
}
// © 2017-2021 crosstales LLC (https://www.crosstales.com)